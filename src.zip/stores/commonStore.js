import { create } from "zustand";

const useCommonStore = create((set) => {
  return {
    activeIndex: 0,
    setActiveIndex: (id) => {
      set(() => {
        return { activeIndex: id };
      });
    },
  };
});

export default useCommonStore;
