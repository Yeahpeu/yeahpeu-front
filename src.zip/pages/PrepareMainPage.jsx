const PrepareMainPage = () => {
  return <div>쇼핑</div>;
};

export default PrepareMainPage;
