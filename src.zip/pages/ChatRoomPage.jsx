const ChatRoomPage = () => {
  return <div>채팅</div>;
};

export default ChatRoomPage;
