const CalendarMolecule = () => {
  return <div>calendars</div>;
};

export default CalendarMolecule;
